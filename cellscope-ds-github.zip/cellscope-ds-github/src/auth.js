// Login system: users in a HashTable, login attempts in a LinkedList. In memory only.
const crypto = require("crypto");
const { HashTable, LinkedList } = require("./dataStructures");

const users = new HashTable(), logs = new LinkedList();
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");
const TTL = 8 * 3600 * 1000;

const hash = (pw, salt) => crypto.scryptSync(pw, salt, 32);
function addUser(email, pw, role) {
  const salt = crypto.randomBytes(16).toString("hex");
  users.set(email, { email, role, salt, hash: hash(pw, salt).toString("hex") });
  return users.get(email);
}
addUser("admin@cellscope.com", "Admin@123", "admin");

const record = (email, ok, why, ip) => logs.addFront({ t: Date.now(), email, ok, why, ip });

function login(email, pw, ip) {
  const u = users.get(email);
  if (!u) { record(email, false, "unknown email", ip); return null; }
  if (!crypto.timingSafeEqual(hash(pw, u.salt), Buffer.from(u.hash, "hex"))) { record(email, false, "wrong password", ip); return null; }
  record(email, true, "", ip); return u;
}
function register(email, pw, ip) {
  if (users.get(email)) return null;
  const u = addUser(email, pw, "user"); record(email, true, "sign up", ip); return u;
}

const sign = p => crypto.createHmac("sha256", SECRET).update(p).digest("base64url");
function makeToken(email) { const p = Buffer.from(email).toString("base64url") + "." + (Date.now() + TTL); return p + "." + sign(p); }
function userFromToken(t) {
  if (!t) return null;
  const i = t.lastIndexOf("."), p = t.slice(0, i), s = Buffer.from(t.slice(i + 1)), e = Buffer.from(sign(p));
  if (s.length !== e.length || !crypto.timingSafeEqual(s, e)) return null;
  const [em, exp] = p.split(".");
  return +exp > Date.now() ? users.get(Buffer.from(em, "base64url").toString()) || null : null;
}
module.exports = { login, register, makeToken, userFromToken, logs };
