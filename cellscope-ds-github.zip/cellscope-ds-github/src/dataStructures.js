// Data structures written by hand (no libraries).
class ListNode{constructor(v){this.v=v;this.next=null}}
class HashTable{constructor(n=16){this.b=Array.from({length:n},()=>[]);this.n=0}
 h(k){let x=5381;for(const c of k)x=(x*33+c.charCodeAt(0))>>>0;return x%this.b.length}
 set(k,v){const B=this.b[this.h(k)];for(const e of B)if(e[0]===k){e[1]=v;return}B.push([k,v]);if(++this.n>this.b.length*2)this.grow()}
 get(k){for(const e of this.b[this.h(k)])if(e[0]===k)return e[1]}
 grow(){const o=this.b.flat();this.b=Array.from({length:this.b.length*2},()=>[]);this.n=0;o.forEach(e=>this.set(e[0],e[1]))}}
class LinkedList{constructor(){this.head=this.tail=null;this.size=0}
 add(v){const n=new ListNode(v);this.tail?this.tail.next=n:this.head=n;this.tail=n;this.size++}
 addFront(v){const n=new ListNode(v);n.next=this.head;this.head=n;this.tail||(this.tail=n);this.size++}
 *[Symbol.iterator](){for(let n=this.head;n;n=n.next)yield n.v}}
class Trie{constructor(){this.r={c:{}}}
 add(w){let n=this.r;for(const ch of w)n=n.c[ch]??={c:{}};n.e=1}
 find(p,lim=8){let n=this.r;for(const ch of p){n=n.c[ch];if(!n)return[]}const o=[];
  (function d(x,s){if(o.length>=lim)return;if(x.e)o.push(s);for(const k of Object.keys(x.c).sort())d(x.c[k],s+k)})(n,p);return o}}
class MinHeap{constructor(f){this.a=[];this.f=f}
 push(v){const a=this.a;a.push(v);let i=a.length-1;while(i>0){const p=(i-1)>>1;if(!this.f(a[i],a[p]))break;[a[i],a[p]]=[a[p],a[i]];i=p}}
 pop(){const a=this.a,t=a[0],l=a.pop();if(a.length){a[0]=l;let i=0;for(;;){let m=i,L=2*i+1,R=L+1;
  if(L<a.length&&this.f(a[L],a[m]))m=L;if(R<a.length&&this.f(a[R],a[m]))m=R;if(m==i)break;[a[i],a[m]]=[a[m],a[i]];i=m}}return t}
 peek(){return this.a[0]}get size(){return this.a.length}}
class BST{constructor(){this.root=null}
 add(k,v){const n={k,v,l:null,r:null};if(!this.root){this.root=n;return}let c=this.root;
  for(;;){const s=k<c.k?"l":"r";if(!c[s]){c[s]=n;return}c=c[s]}}
 inorder(){const o=[];(function w(n){if(n){w(n.l);o.push(n.v);w(n.r)}})(this.root);return o}}
class CircularQueue{constructor(c){this.a=Array(c);this.c=c;this.h=0;this.n=0}
 enqueue(v){this.a[(this.h+this.n)%this.c]=v;this.n<this.c?this.n++:this.h=(this.h+1)%this.c}
 items(){return Array.from({length:this.n},(_,i)=>this.a[(this.h+i)%this.c])}}
class Queue{constructor(){this.h=this.t=null;this.n=0}
 enqueue(v){const x=new ListNode(v);this.t?this.t.next=x:this.h=x;this.t=x;this.n++}
 dequeue(){const x=this.h;if(!x)return;this.h=x.next;this.h||(this.t=null);this.n--;return x.v}}
class Stack{constructor(){this.a=[]}push(v){this.a.push(v)}pop(){return this.a.pop()}get size(){return this.a.length}}
function mergeSort(a,f){if(a.length<2)return a;const m=a.length>>1,l=mergeSort(a.slice(0,m),f),r=mergeSort(a.slice(m),f),o=[];
 let i=0,j=0;while(i<l.length&&j<r.length)o.push(f(l[i],r[j])<=0?l[i++]:r[j++]);return o.concat(l.slice(i),r.slice(j))}

module.exports={ListNode,HashTable,LinkedList,Trie,MinHeap,BST,CircularQueue,Queue,Stack,mergeSort};
