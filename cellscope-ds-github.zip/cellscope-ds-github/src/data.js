// Generates 200 vehicles x 20 sessions and stores them in data structures (no database).
const {HashTable,LinkedList,Trie,MinHeap,BST,CircularQueue}=require("./dataStructures");
const rng=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const gs=r=>Math.sqrt(-2*Math.log(r()||1e-9))*Math.cos(6.2832*r());
const ST=["BKC","Powai","Thane","Andheri","Vashi","Lower Parel","Borivali","Hinjewadi","Nashik Rd","Lonavala"];
const MD=[["Tata Nexon EV",40.5],["Tata Tigor EV",26],["Tata Punch EV",35],["MG ZS EV",50.3],["MG Comet EV",17.3],["Hyundai Kona",39.2],["Mahindra XUV400",39.4],["BYD Atto 3",60.5]];
const AR=[["Healthy battery",35,11,-.12,.1],["Excellent habits",33,7,-.07,0],["Runs hot (fast charging)",42,40,-.35,.3],["Declining health",41,25,-.9,.5],["Heavy daily use",38,22,-.25,.25]];
const V=new HashTable(),trie=new Trie(),bst=new BST(),hot=new MinHeap((a,b)=>a.peak<b.peak),demoNos=[];
(function(){const used=new Set,L="ABCDEFGHJKLMNPRSTUVWXYZ",D=[["MH01AB1234",0,0],["MH02CD5678",3,2],["MH03EF9012",5,3],["MH04GH3456",1,1]];
for(let n=0;n<200;n++){const r=rng(500+n);let no,mi,ai;
 if(n<4){[no,mi,ai]=D[n];demoNos.push(no)}else{do{no=["MH","MH","MH","KA","DL","GJ","TN"][r()*7|0]+String(1+(r()*49|0)).padStart(2,"0")+L[r()*23|0]+L[r()*23|0]+(1000+(r()*9000|0))}while(used.has(no));mi=r()*8|0;ai=r()*5|0}
 used.add(no);const[model,kwh]=MD[mi],[note,b,kw,sl,fu]=AR[ai],base=b+gs(r)*1.2,pw=Math.max(3,kw+gs(r)*2),s0=n<4?100:100-r()*8,ses=new LinkedList,cq=new CircularQueue(5);let last;
 for(let i=0;i<20;i++){const peak=+(base+gs(r)*2+pw/20).toFixed(1),s={vn:no,st:ST[r()*10|0],t:Date.UTC(2026,5,1+2*i,6+(r()*16|0),r()*60|0),dur:25+(r()*65|0),peak,kw:+Math.max(2,pw+gs(r)*pw*.2).toFixed(1),soc:r()<fu?100:70+(r()*25|0),soh:+(s0+sl*(i+1)+gs(r)*.1).toFixed(1)};
  ses.add(s);cq.enqueue(peak);last=s;if(hot.size<5)hot.push(s);else if(s.peak>hot.peek().peak){hot.pop();hot.push(s)}}
 const q=cq.items(),v={no,model,kwh,note,ses,pred:+(q.reduce((a,x)=>a+x,0)/q.length+.5).toFixed(1),soh:last.soh};V.set(no,v);trie.add(no);bst.add(last.soh,v)}})();

module.exports={V,trie,bst,hot,demoNos};
