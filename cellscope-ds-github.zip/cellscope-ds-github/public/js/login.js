// Frontend: login / sign-up form. Talks to the backend API.
const $ = s => document.querySelector(s);
async function send(path) {
  $("#le").textContent = "";
  try {
    const r = await fetch("/api/" + path, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: $("#em").value, password: $("#pw").value }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok) location.href = "/"; else $("#le").textContent = j.error || "Something went wrong.";
  } catch { $("#le").textContent = "Could not reach the server."; }
}
$("#lf").onsubmit = e => { e.preventDefault(); send("login"); };
$("#su").onclick = () => send("register");
