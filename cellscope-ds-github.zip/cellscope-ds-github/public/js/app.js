// Frontend: dashboard. All data comes from the backend API (src/ data structures).
const $ = s => document.querySelector(s);
const api = async p => {
  const r = await fetch("/api" + p);
  if (r.status === 401) { location.href = "/login.html"; throw new Error("Please log in."); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || "Request failed");
  return j;
};
class Stack { constructor() { this.a = []; } push(v) { this.a.push(v); } pop() { return this.a.pop(); } }   // Back-button history
const nav = new Stack;
let cur = null, sk = "t", asc = true;
const view = n => ["land", "dash", "fleet"].forEach(x => $("#" + x).hidden = x !== n);
const fd = t => new Date(t).toISOString().slice(0, 10);

api("/me").then(u => { $("#who").textContent = u.email; $("#fl").hidden = u.role !== "admin"; }).catch(() => {});
api("/demo").then(L => $("#demo").innerHTML = L.map(n => `<button type="button" data-v="${n}">${n}</button>`).join(""));
$("#demo").onclick = e => e.target.dataset.v && open(e.target.dataset.v);
$("#q").oninput = async e => {
  const p = e.target.value.trim();
  $("#sg").innerHTML = p ? (await api("/suggest?prefix=" + encodeURIComponent(p))).map(x => `<li><button type="button" data-v="${x}">${x}</button></li>`).join("") : "";
};
$("#sg").onclick = e => e.target.dataset.v && open(e.target.dataset.v);
$("#bk").onclick = () => { const p = nav.pop(); if (p) open(p, false); else { cur = null; view("land"); } };
$("#fl").onclick = () => { nav.push(cur ? cur.no : null); fleet(); };
$("#lo").onclick = async () => { await fetch("/api/logout", { method: "POST" }); location.href = "/login.html"; };

async function open(no, push = true) {
  try {
    const v = await api(`/vehicles/${encodeURIComponent(no)}?sort=${sk}&dir=${asc ? "asc" : "desc"}`);
    $("#m").textContent = ""; if (push && cur) nav.push(cur.no); cur = v; draw(v);
  } catch (e) { $("#m").textContent = e.message; }
}
function line(a, c, lab) {
  const W = 600, H = 140, mn = Math.min(...a), mx = Math.max(...a), sp = mx - mn || 1,
    pts = a.map((y, i) => `${10 + i * (W - 20) / (a.length - 1)},${H - 10 - (y - mn) / sp * (H - 20)}`).join(" ");
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${lab}"><polyline points="${pts}" fill="none" stroke="${c}" stroke-width="3"/></svg><p class="mu sm">${lab}: min ${mn.toFixed(1)}, max ${mx.toFixed(1)}</p>`;
}
function draw(v) {
  const cols = [["t", "Date"], ["st", "Station"], ["dur", "Min"], ["peak", "Peak °C"], ["kw", "kW"], ["soc", "Charge %"], ["soh", "Health %"]];
  $("#dash").innerHTML = `<div class="card"><h2>${v.no} · ${v.model}</h2><p class="mu">${v.kwh} kWh · ${v.note}</p><div class="g">
  <div class="k">Battery health<b>${v.soh}%</b></div><div class="k">Predicted next peak<b>${v.pred} °C</b><span class="mu sm">avg of last 5 (circular queue)</span></div>
  <div class="k">Heat alerts<b class="${v.alerts ? "bad" : ""}">${v.alerts}</b><span class="mu sm">from alert queue</span></div><div class="k">Sessions<b>${v.sessions.length}</b></div></div></div>
  <div class="card"><h2>Trends</h2>${line(v.trend.soh, "#0b9bb0", "Battery health % over sessions")}${line(v.trend.peak, "#d9822b", "Peak temperature °C over sessions")}</div>
  <div class="card"><h2>Charging sessions</h2><p class="mu sm">Click a heading to sort (merge sort on the server).</p><div class="tb"><table><thead><tr>${cols.map(c => `<th><button type="button" data-k="${c[0]}">${c[1]}${sk === c[0] ? (asc ? " ▲" : " ▼") : ""}</button></th>`).join("")}</tr></thead><tbody>
  ${v.sessions.map(s => `<tr><td>${fd(s.t)}</td><td>${s.st}</td><td>${s.dur}</td><td class="${s.peak > 45 || s.peak < 15 ? "bad" : ""}">${s.peak}</td><td>${s.kw}</td><td>${s.soc}</td><td>${s.soh}</td></tr>`).join("")}</tbody></table></div></div>`;
  $("#dash").querySelector("thead").onclick = e => { const k = e.target.closest("button")?.dataset.k; if (!k) return; asc = sk === k ? !asc : true; sk = k; open(v.no, false); };
  view("dash");
}
const DS = [["Hash table (chaining)", "Vehicle and user lookup by key", "O(1) average"], ["Linked list", "Each vehicle's sessions; login log", "O(1) append"], ["Trie", "Vehicle number autocomplete", "O(length)"], ["Min-heap (size 5)", "Hottest sessions in the fleet", "O(log k) insert"], ["Binary search tree", "Health ranking via in-order traversal", "O(log n) avg insert"], ["Circular queue", "Last 5 peaks give the prediction", "O(1)"], ["Queue", "Heat alerts, first-in first-out", "O(1)"], ["Stack", "Back button history (this file)", "O(1)"], ["Merge sort", "Sortable session table", "O(n log n)"]];
async function fleet() {
  let f; try { f = await api("/fleet"); } catch (e) { return alert(e.message); }
  const row = v => `<tr><td>${v.no}</td><td>${v.model}</td><td>${v.soh}%</td></tr>`;
  $("#fleet").innerHTML = `<div class="card"><h2>Fleet overview (${f.vehicles} vehicles)</h2><div class="g"><div class="k">Sessions<b>${f.vehicles * 20}</b></div><div class="k">Hash table buckets<b>${f.buckets}</b></div></div></div>
  <div class="card"><h2>5 hottest sessions (heap)</h2><div class="tb"><table><tbody>${f.hottest.map(s => `<tr><td>${s.vn}</td><td>${fd(s.t)}</td><td>${s.st}</td><td class="bad">${s.peak} °C</td></tr>`).join("")}</tbody></table></div></div>
  <div class="card"><h2>Lowest health (BST, left end)</h2><div class="tb"><table><tbody>${f.lowest.map(row).join("")}</tbody></table></div><h2 style="margin-top:14px">Highest health (BST, right end)</h2><div class="tb"><table><tbody>${f.highest.map(row).join("")}</tbody></table></div></div>
  <div class="card"><h2>Login log (linked list, newest first)</h2><div class="tb"><table><thead><tr><th>Time</th><th>Email</th><th>Result</th></tr></thead><tbody>${f.logins.map(l => `<tr><td>${new Date(l.t).toLocaleString()}</td><td>${l.email}</td><td class="${l.ok ? "" : "bad"}">${l.ok ? "Success" : "Failed: " + l.why}</td></tr>`).join("")}</tbody></table></div></div>
  <div class="card"><h2>Data structures used</h2><div class="tb"><table><thead><tr><th>Structure</th><th>Used for</th><th>Cost</th></tr></thead><tbody>${DS.map(d => `<tr><td>${d[0]}</td><td>${d[1]}</td><td>${d[2]}</td></tr>`).join("")}</tbody></table></div></div>`;
  view("fleet");
}
